// js/index.js
document.addEventListener('DOMContentLoaded', function() {
    addEnhancedSearch();
    addImageGallery();
    addSmoothAnimations();
});

// Enhanced search
function addEnhancedSearch() {
    const searchHTML = `
        <div class="search-hero">
            <h3>Find Diabetes Support</h3>
            <div class="search-container">
                <input type="text" placeholder="Search resources, tips, or services..." id="homeSearch">
            </div>
            <div id="homeResults" class="search-results"></div>
        </div>
    `;
    
    const homeSection = document.getElementById('home');
    homeSection.insertAdjacentHTML('afterbegin', searchHTML);
    
    const resources = [
        'Personalized coaching and diabetes management plans',
        'Access to modern glucose monitoring devices',
        'Nutrition guidance and meal ideas tailored to you',
        'Medication reminders and delivery coordination',
        'Online check-ins and community support'
    ];
    
    const searchInput = document.getElementById('homeSearch');
    const searchResults = document.getElementById('homeResults');
    
    function performSearch(query = '') {
        const results = resources.filter(resource => 
            resource.toLowerCase().includes(query.toLowerCase())
        );
        
        if (results.length > 0) {
            searchResults.innerHTML = results.map(resource => `
                <div class="resource-card">
                    <p>${resource}</p>
                </div>
            `).join('');
        } else {
            searchResults.innerHTML = '<div class="no-results">No results found</div>';
        }
    }
    
    searchInput.addEventListener('input', (e) => performSearch(e.target.value));
    
    
    performSearch();
}

//  gallery
function addImageGallery() {
    const marquee = document.querySelector('marquee');
    const images = Array.from(marquee.querySelectorAll('img'));
    
   
    const galleryHTML = `
        <div class="gallery-section">
            <h3>Diabetes Care Gallery</h3>
            <div class="gallery-grid">
                ${images.map(img => `
                    <div class="gallery-item">
                        <img src="${img.src}" alt="${img.alt}">
                    </div>
                `).join('')}
            </div>
        </div>
    `;
    
    
    marquee.insertAdjacentHTML('afterend', galleryHTML);
    marquee.style.display = 'none';
    
    document.querySelectorAll('.gallery-item').forEach((item, index) => {
        item.addEventListener('click', () => {
            const lightbox = document.createElement('div');
            lightbox.className = 'lightbox';
            lightbox.innerHTML = `
                <div class="lightbox-content">
                    <button class="lightbox-close">×</button>
                    <img src="${images[index].src}" alt="${images[index].alt}">
                </div>
            `;
            document.body.appendChild(lightbox);
            
          
            lightbox.querySelector('.lightbox-close').addEventListener('click', () => {
                lightbox.remove();
            });
            
            lightbox.addEventListener('click', (e) => {
                if (e.target === lightbox) lightbox.remove();
            });
            
            document.addEventListener('keydown', function lightboxKeyHandler(e) {
                if (e.key === 'Escape') lightbox.remove();
                document.removeEventListener('keydown', lightboxKeyHandler);
            });
        });
    });
}


function addSmoothAnimations() {
    
    const main = document.querySelector('main');
    main.style.opacity = '0';
    main.style.transition = 'all 0.8s ease';
    
    setTimeout(() => {
        main.style.opacity = '1';
    }, 200);
    
 
    document.querySelectorAll('nav a').forEach(link => {
        link.style.transition = 'all 0.3s ease';
        link.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
            this.style.color = '#ffdd00';
        });
        link.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.color = 'white';
        });
    });
    
    
    document.querySelectorAll('#home li').forEach((item, index) => {
        item.style.opacity = '0';
        item.style.transform = 'translateX(-20px)';
        item.style.transition = `all 0.5s ease ${index * 0.1}s`;
        
        setTimeout(() => {
            item.style.opacity = '1';
            item.style.transform = 'translateX(0)';
        }, 600 + index * 100);
        
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateX(10px)';
            this.style.background = '#e3f2fd';
        });
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateX(0)';
            this.style.background = 'transparent';
        });
    });
}

const enhancedStyles = `
    .search-hero {
        background: linear-gradient(135deg, #0077b6, #00b4d8);
        color: white;
        padding: 25px;
        border-radius: 15px;
        margin-bottom: 30px;
        text-align: center;
    }
    
    .search-hero h3 {
        margin-bottom: 15px;
        font-size: 1.4rem;
    }
    
    .search-container {
        max-width: 500px;
        margin: 0 auto;
    }
    
    .search-container input {
        width: 100%;
        padding: 12px 20px;
        border: none;
        border-radius: 25px;
        font-size: 1rem;
    }
    
    .search-results {
        margin-top: 20px;
        display: grid;
        gap: 15px;
    }
    
    .resource-card {
        background: white;
        color: #333;
        padding: 15px;
        border-radius: 8px;
        transition: transform 0.3s;
    }
    
    .resource-card:hover {
        transform: translateY(-3px);
    }
    
    .gallery-section {
        margin: 40px 0;
        text-align: center;
    }
    
    .gallery-section h3 {
        color: #0077b6;
        margin-bottom: 20px;
    }
    
    .gallery-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        max-width: 800px;
        margin: 0 auto;
    }
    
    .gallery-item {
        border-radius: 10px;
        overflow: hidden;
        cursor: pointer;
        transition: transform 0.3s;
    }
    
    .gallery-item:hover {
        transform: scale(1.05);
    }
    
    .gallery-item img {
        width: 100%;
        height: 150px;
        object-fit: cover;
    }
    
    .lightbox {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.9);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
    }
    
    .lightbox-content {
        position: relative;
        max-width: 90%;
        max-height: 90%;
    }
    
    .lightbox-content img {
        max-width: 100%;
        max-height: 80vh;
        border-radius: 10px;
    }
    
    .lightbox-close {
        position: absolute;
        top: -40px;
        right: 0;
        background: none;
        border: none;
        color: white;
        font-size: 2rem;
        cursor: pointer;
    }
    
    .no-results {
        padding: 15px;
        text-align: center;
        color: white;
    }
`;

document.head.insertAdjacentHTML('beforeend', `<style>${enhancedStyles}</style>`);