// js/enquiry.js
document.addEventListener('DOMContentLoaded', function() {
    addServiceSelection();
    addFormValidation();
    addFormAnimations();
    addFormEnhancements();
    addMap();  // Add the map functionality
});

function addServiceSelection() {
    const form = document.querySelector('#enquiry form');
    
    // Create service selection section
    const serviceHTML = `
        <div class="form-group">
            <label for="service">Service you're interested in:</label>
            <select id="service" name="service" required>
                <option value="">Select a service</option>
                <option value="diabetes-management">Diabetes Management Programs</option>
                <option value="medication-delivery">Medication Delivery</option>
                <option value="nutrition-planning">Nutrition and Meal Planning</option>
                <option value="fitness-coaching">Fitness and Lifestyle Coaching</option>
                <option value="digital-tools">Digital Health Tools</option>
                <option value="volunteer">Volunteer Opportunities</option>
                <option value="sponsorship">Sponsorship/Partnership</option>
                <option value="other">Other</option>
            </select>
        </div>
        
        <div class="form-group">
            <label for="urgency">Urgency Level:</label>
            <select id="urgency" name="urgency">
                <option value="low">Low - General enquiry</option>
                <option value="medium" selected>Medium - Would like info soon</option>
                <option value="high">High - Need immediate assistance</option>
            </select>
        </div>
    `;
    
    // Insert after email field
    const emailField = document.getElementById('email');
    emailField.parentElement.insertAdjacentHTML('afterend', serviceHTML);
    
    const budgetHTML = `
        <div class="form-group" id="budgetGroup" style="display: none;">
            <label for="budget">Estimated Budget (if applicable):</label>
            <input type="text" id="budget" name="budget" placeholder="e.g., $100-200 per month">
        </div>
    `;
    
    const serviceSelect = document.getElementById('service');
    serviceSelect.parentElement.insertAdjacentHTML('afterend', budgetHTML);
 
    serviceSelect.addEventListener('change', function() {
        const budgetGroup = document.getElementById('budgetGroup');
        const paidServices = ['diabetes-management', 'medication-delivery', 'nutrition-planning', 'fitness-coaching', 'digital-tools'];
        
        if (paidServices.includes(this.value)) {
            budgetGroup.style.display = 'block';
        } else {
            budgetGroup.style.display = 'none';
        }
    });
}

// Enhanced form validation
function addFormValidation() {
    const form = document.querySelector('#enquiry form');
    const inputs = form.querySelectorAll('input, textarea, select');
    
    inputs.forEach(input => {
        
        input.addEventListener('focus', function() {
            this.style.borderColor = '#0066cc';
            this.style.boxShadow = '0 0 5px rgba(0,102,204,0.3)';
        });
        
        input.addEventListener('blur', function() {
            this.style.borderColor = '#ccc';
            this.style.boxShadow = 'none';
            validateField(this);
        });
        
        if (input.type === 'email') {
            input.addEventListener('input', function() {
                validateEmail(this);
            });
        }
        
        if (input.id === 'budget') {
            input.addEventListener('input', function() {
                validateBudget(this);
            });
        }
    });
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        let isValid = true;
        inputs.forEach(input => {
            if (!validateField(input)) {
                isValid = false;
            }
        });
        
        if (isValid) {
            processEnquiry();
        }
    });
}

function validateField(field) {
    const value = field.value.trim();
    const errorElement = field.parentElement.querySelector('.error-message') || createErrorElement(field);
    
    errorElement.textContent = '';
    field.style.borderColor = '#ccc';
    
    if (field.hasAttribute('required') && !value) {
        showFieldError(field, errorElement, 'This field is required');
        return false;
    }
    
    // Email validation
    if (field.type === 'email' && value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            showFieldError(field, errorElement, 'Please enter a valid email address');
            return false;
        }
    }
   
    if (field.id === 'name' && value.length < 2) {
        showFieldError(field, errorElement, 'Name must be at least 2 characters long');
        return false;
    }
    
    return true;
}

function validateEmail(emailField) {
    const value = emailField.value.trim();
    const errorElement = emailField.parentElement.querySelector('.error-message') || createErrorElement(emailField);
    
    if (value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        emailField.style.borderColor = '#dc3545';
        errorElement.textContent = 'Please enter a valid email';
    } else {
        emailField.style.borderColor = '#ccc';
        errorElement.textContent = '';
    }
}

function validateBudget(budgetField) {
    const value = budgetField.value.trim();
    const errorElement = budgetField.parentElement.querySelector('.error-message') || createErrorElement(budgetField);
    
    if (value && !/^[\$£€]?\d+([\.,]\d+)?([\-\s]?[\$£€]?\d+([\.,]\d+)?)?\s*(per\s*(month|year))?$/i.test(value)) {
        budgetField.style.borderColor = '#dc3545';
        errorElement.textContent = 'Please enter a valid budget (e.g., $100-200 per month)';
    } else {
        budgetField.style.borderColor = '#ccc';
        errorElement.textContent = '';
    }
}

function processEnquiry() {
    const form = document.querySelector('#enquiry form');
    const formData = new FormData(form);
    
    const service = formData.get('service');
    const urgency = formData.get('urgency');
    const budget = formData.get('budget');
    
    let responseMessage = '';
    let responseDetails = '';
    
    switch(service) {
        case 'diabetes-management':
            responseMessage = 'Diabetes Management Program Enquiry';
            responseDetails = budget ? 
                `Our diabetes management programs typically range from $50-150 per month. For your budget of ${budget}, we recommend our Standard Plan which includes weekly coaching sessions and digital tracking.` :
                'Our diabetes management programs start from $50 per month. A consultant will contact you to discuss suitable options.';
            break;
        case 'medication-delivery':
            responseMessage = 'Medication Delivery Service Enquiry';
            responseDetails = 'Our medication delivery service is available in your area. Delivery fees start from $5 per delivery with free delivery on orders over $50.';
            break;
        case 'nutrition-planning':
            responseMessage = 'Nutrition Planning Enquiry';
            responseDetails = budget ? 
                `For your budget of ${budget}, we offer personalized meal plans with ${budget.includes('200') ? 'premium' : 'basic'} nutritional guidance and monthly reviews.` :
                'Our nutrition planning services start from $30 per month for basic meal plans.';
            break;
        case 'fitness-coaching':
            responseMessage = 'Fitness Coaching Enquiry';
            responseDetails = 'Our fitness coaching programs include personalized exercise routines and lifestyle guidance. Prices start from $40 per month.';
            break;
        case 'digital-tools':
            responseMessage = 'Digital Tools Enquiry';
            responseDetails = 'Our digital health tools include glucose tracking apps and remote monitoring. Basic features are free, premium features start from $10/month.';
            break;
        case 'volunteer':
            responseMessage = 'Volunteer Application';
            responseDetails = 'Thank you for your interest in volunteering! Our volunteer coordinator will contact you within 2-3 business days to discuss opportunities.';
            break;
        case 'sponsorship':
            responseMessage = 'Sponsorship/Partnership Enquiry';
            responseDetails = 'We appreciate your interest in partnership. Our partnerships manager will contact you to discuss collaboration opportunities.';
            break;
        default:
            responseMessage = 'General Enquiry';
            responseDetails = 'Thank you for your enquiry. Our team will respond within 24-48 hours.';
    }
    
    if (urgency === 'high') {
        responseDetails += ' We have noted your urgent request and will prioritize your enquiry.';
    }
    
    showEnquiryResponse(responseMessage, responseDetails);
    form.reset();
    document.getElementById('budgetGroup').style.display = 'none';
}

function showEnquiryResponse(title, details) {}
    const responseHTML = `
        <div class="enquiry-response">
            <div class="response-header">
                <h3>${title}</h3>
            </div>
            <div class="response-content">
                <p>${details}</p>
                <div class="response-actions">
                    <button onclick="this.parentElement.parentElement.remove()">Close</button>
                </div>
            </div>
        </div>
    `;
