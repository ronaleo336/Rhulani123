// js/services.js
document.addEventListener('DOMContentLoaded', function() {
    fixFitnessImage();
    createServicesSearch();
    createImageLightbox();
    addServicesAnimations();
});


function fixFitnessImage() {
    const servicesList = document.querySelector('#services ul');
    const listItems = Array.from(servicesList.children);
    
    // Find fitness item and digital tools item
    let fitnessItem, digitalItem;
    
    listItems.forEach(item => {
        if (item.textContent.includes('Fitness and Lifestyle Coaching')) {
            fitnessItem = item;
        }
        if (item.textContent.includes('Digital Health Tools')) {
            digitalItem = item;
        }
    });
    
   
    if (fitnessItem && digitalItem) {
        const fitnessImg = fitnessItem.querySelector('img');
        const digitalImg = digitalItem.querySelector('img');
        
        if (fitnessImg && digitalImg) {
            
            fitnessItem.appendChild(digitalImg);
            digitalItem.appendChild(fitnessImg);
        }
    }
}

function createServicesSearch() {
    const servicesSection = document.getElementById('services');
    if (!servicesSection) return;

    const searchBox = document.createElement('div');
    searchBox.className = 'services-search';
    searchBox.innerHTML = `
        <h2>Find Services</h2>
        <input type="text" id="servicesSearch" placeholder="Search our services..." aria-label="Search services">
        <div id="servicesResults" class="search-results" aria-live="polite"></div>
    `;

   
    const referenceNode = servicesSection.querySelector('p') || servicesSection.querySelector('ul') || null;
    servicesSection.insertBefore(searchBox, referenceNode);


    const listItems = Array.from(servicesSection.querySelectorAll('ul li'));
    const servicesFromDom = listItems.map(li => ({
        text: li.textContent.trim(),
        element: li
    }));

    M
    const fallbackServices = [
        'Diabetes Management Programs – Step-by-step support and personalized plans',
        'Medication Delivery – Reliable delivery of essential medicines',
        'Nutrition and Meal Planning – Customized meal plans by dietitians',
        'Fitness and Lifestyle Coaching – Exercise routines and stress management',
        'Digital Health Tools – Apps and devices for monitoring glucose'
    ];

    const searchInput = document.getElementById('servicesSearch');
    const searchResults = document.getElementById('servicesResults');

    function clearHighlights() {
        listItems.forEach(li => {
            li.style.display = '';
            li.classList.remove('search-highlight');
        });
    }

    function showResults(matches) {
        if (matches.length === 0) {
            searchResults.innerHTML = '<div class="no-results">No services found</div>';
            return;
        }
        searchResults.innerHTML = matches.map(m => {
            // use a data attribute index for clickable behaviour
            return `<div class="service-result" data-text="${escapeHtml(m.text || m)}">${escapeHtml(m.text || m)}</div>`;
        }).join('');
        // attach click handlers for results
        Array.from(searchResults.children).forEach(node => {
            node.addEventListener('click', () => {
                const text = node.getAttribute('data-text');
                // try to find matching DOM item and scroll to it
                const match = servicesFromDom.find(s => s.text === text);
                if (match && match.element) {
                    match.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    // highlight temporarily
                    match.element.classList.add('search-highlight');
                    setTimeout(() => match.element.classList.remove('search-highlight'), 2000);
                }
            });
        });
    }

    function escapeHtml(str) {
        return String(str).replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]));
    }

    searchInput.addEventListener('input', function() {
        const query = this.value.trim().toLowerCase();

        // If we have DOM list items, show/hide them based on query
        if (servicesFromDom.length > 0) {
            if (!query) {
                clearHighlights();
                searchResults.innerHTML = '';
                return;
            }

            const matches = [];
            servicesFromDom.forEach(item => {
                const matchesItem = item.text.toLowerCase().includes(query);
                item.element.style.display = matchesItem ? '' : 'none';
                if (matchesItem) matches.push(item.text);
            });

            if (matches.length) {
                showResults(matches);
            } else {
                searchResults.innerHTML = '<div class="no-results">No services found</div>';
            }
            return;
        }

        if (!query) {
            searchResults.innerHTML = '';
            return;
        }

        const matches = fallbackServices.filter(service =>
            service.toLowerCase().includes(query)
        );

        if (matches.length > 0) {
            searchResults.innerHTML = matches.map(service =>
                `<div class="service-result">${escapeHtml(service)}</div>`
            ).join('');
        } else {
            searchResults.innerHTML = '<div class="no-results">No services found</div>';
        }
    });

    const searchStyles = `
        .services-search {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .services-search h2 {
            color: #0066cc;
            margin-bottom: 15px;
            text-align: center;
        }
        #servicesSearch {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #0066cc;
            border-radius: 8px;
            font-size: 1rem;
        }
        #servicesSearch:focus {
            outline: none;
            border-color: #003366;
        }
        .search-results {
            margin-top: 15px;
        }
        .service-result {
            padding: 12px 15px;
            margin-bottom: 8px;
            background: #e6f2ff;
            border-left: 4px solid #0066cc;
            border-radius: 6px;
            cursor: pointer;
        }
        .no-results {
            padding: 15px;
            text-align: center;
            color: #666;
            background: #f8f9fa;
            border-radius: 6px;
        }
        .search-highlight {
            background: rgba(0,102,204,0.08);
            transition: background 0.3s;
        }
    `;
    addStyles(searchStyles);
}


function createImageLightbox() {
    const servicesSection = document.getElementById('services');
    const images = servicesSection.querySelectorAll('img');
    
    //lightbox
    const lightbox = document.createElement('div');
    lightbox.id = 'servicesLightbox';
    lightbox.innerHTML = `
        <div class="lightbox-content">
            <span class="close">&times;</span>
            <img src="" alt="">
            <div class="caption"></div>
        </div>
    `;
    document.body.appendChild(lightbox);
    
    images.forEach(img => {
        img.style.cursor = 'pointer';
        img.addEventListener('click', function() {
            openLightbox(this.src, this.alt);
        });
    });
    
    function openLightbox(src, caption) {
        const lightbox = document.getElementById('servicesLightbox');
        const lightboxImg = lightbox.querySelector('img');
        const lightboxCaption = lightbox.querySelector('.caption');
        
        lightboxImg.src = src;
        lightboxCaption.textContent = caption;
        lightbox.classList.add('active');
        
        const closeBtn = lightbox.querySelector('.close');
        closeBtn.onclick = function() {
            lightbox.classList.remove('active');
        };
        
        lightbox.onclick = function(e) {
            if (e.target === lightbox) {
                lightbox.classList.remove('active');
            }
        };
        
        document.addEventListener('keydown', function lightboxKeyHandler(e) {
            if (e.key === 'Escape') {
                lightbox.classList.remove('active');
                document.removeEventListener('keydown', lightboxKeyHandler);
            }
        });
    }
    
    const lightboxStyles = `
        #servicesLightbox {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.9);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        #servicesLightbox.active {
            display: flex;
        }
        #servicesLightbox .lightbox-content {
            position: relative;
            max-width: 90%;
            max-height: 90%;
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }
        #servicesLightbox img {
            max-width: 100%;
            max-height: 70vh;
            border-radius: 8px;
        }
        #servicesLightbox .close {
            position: absolute;
            top: 10px;
            right: 15px;
            color: #0066cc;
            font-size: 30px;
            font-weight: bold;
            cursor: pointer;
        }
        #servicesLightbox .caption {
            color: #0066cc;
            font-weight: bold;
            margin-top: 10px;
        }
    `;
    addStyles(lightboxStyles);
}


function addServicesAnimations() {
    const servicesSection = document.getElementById('services');
    servicesSection.style.opacity = '0';
    servicesSection.style.transform = 'translateY(20px)';
    servicesSection.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    
    setTimeout(() => {
        servicesSection.style.opacity = '1';
        servicesSection.style.transform = 'translateY(0)';
    }, 300);
    
    const serviceItems = servicesSection.querySelectorAll('li');
    serviceItems.forEach(item => {
        item.style.transition = 'transform 0.3s ease';
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
}


function addStyles(css) {
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
}