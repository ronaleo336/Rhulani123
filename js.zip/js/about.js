// js/about.js
document.addEventListener('DOMContentLoaded', function() {
    createSimpleAccordion();
    createGalleryFromExistingImages();
    createSimpleSearch();
    addSimpleAnimations();
});

function createSimpleAccordion() {
    const focusList = document.querySelector('#about ul');
    if (!focusList) return;
    
    const listItems = focusList.querySelectorAll('li');
    
    
    const descriptions = {
        'Education': 'Comprehensive diabetes education programs tailored to your needs.',
        'Prevention': 'Early detection and lifestyle interventions to prevent complications.',
        'Long-term well-being': 'Continuous monitoring and personalized care plans.',
        'Medication Delivery': 'Convenient medication delivery with automatic refills.'
    };

    listItems.forEach(item => {
        const text = item.textContent;
        
        const accordionItem = document.createElement('div');
        accordionItem.className = 'accordion-item';
        
        accordionItem.innerHTML = `
            <div class="accordion-header">
                ${text}
                <span class="accordion-icon">+</span>
            </div>
            <div class="accordion-content">
                <p>${descriptions[text]}</p>
            </div>
        `;
        
      
        focusList.replaceChild(accordionItem, item);
        const header = accordionItem.querySelector('.accordion-header');
        header.addEventListener('click', function() {
            accordionItem.classList.toggle('active');
        });
    });
    
    const accordionStyles = `
        .accordion-item {
            border: 1px solid #0077b6;
            border-radius: 5px;
            margin-bottom: 10px;
            overflow: hidden;
        }
        
        .accordion-header {
            background-color: #0077b6;
            color: white;
            padding: 15px;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: bold;
        }
        
        .accordion-content {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
            background-color: white;
        }
        
        .accordion-content p {
            padding: 15px;
            margin: 0;
        }
        
        .accordion-item.active .accordion-content {
            max-height: 200px;
        }
        
        .accordion-item.active .accordion-icon {
            transform: rotate(45deg);
        }
        
        .accordion-icon {
            transition: transform 0.3s ease;
        }
    `;
    
    addStyles(accordionStyles);
}
function createGalleryFromExistingImages() {
    const aboutSection = document.getElementById('about');
    if (!aboutSection) return;

    // Create gallery section
    const gallerySection = document.createElement('section');
    gallerySection.className = 'image-gallery';
    gallerySection.innerHTML = '<h3>Diabetes Care Gallery</h3>';

    const galleryContainer = document.createElement('div');
    galleryContainer.className = 'gallery-container';
    gallerySection.appendChild(galleryContainer);

    const headerImage = document.querySelector('header img');
    const headerImageSrc = headerImage ? headerImage.src : '';

    const galleryItems = [
        {
            src:"Images/insulinpens-2.jpg",
            caption: 'Diabetes Care Devices',
            description: 'Modern technology for diabetes management'
        },
        {
            src: "Images/diabetes-t2-lifestyle.jpg",
            caption: 'Fitness and Wellness',
            description: 'Exercise and physical activity for better control'
        },
        {
            src:"Images/OIP.webp",  
            caption: 'Blood Glucose Monitoring',
            description: 'Regular monitoring for better control'
        },
        {
            src: "Images/cs-type-2-diabetes-unique-treatment-plan-722x406.jpg", 
            caption: 'Insulin Management', 
            description: 'Proper insulin administration for optimal health'
        }
    ];

    galleryItems.forEach((item) => {
        const galleryItem = document.createElement('div');
        galleryItem.className = 'gallery-item';

        galleryItem.innerHTML = `
            <img src="${item.src}" alt="${item.caption}">
            <div class="image-caption">${item.caption}</div>
        `;

        galleryContainer.appendChild(galleryItem);

        galleryItem.addEventListener('click', function() {
            openLightbox(item.src, item.caption, item.description);
        });
    });

    const firstParagraph = aboutSection.querySelector('p');
    aboutSection.insertBefore(gallerySection, firstParagraph.nextSibling);

    // Create lightbox
    const lightbox = document.createElement('div');
    lightbox.id = 'lightbox';
    lightbox.innerHTML = `
        <div class="lightbox-content">
            <span class="close">&times;</span>
            <img src="" alt="">
            <div class="caption"></div>
        </div>
    `;
    document.body.appendChild(lightbox);

    // Add gallery styles
    const galleryStyles = `
        .image-gallery {
            margin: 30px 0;
        }

        .image-gallery h3 {
            text-align: center;
            color: #0077b6;
            margin-bottom: 20px;
        }

        .gallery-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        .gallery-item {
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            cursor: pointer;
            transition: transform 0.3s ease;
            background: white;
        }

        .gallery-item:hover {
            transform: translateY(-5px);
        }

        .gallery-item img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            display: block;
        }

        .image-caption {
            padding: 10px;
            text-align: center;
            font-weight: bold;
            color: #0077b6;
        }

        #lightbox {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.8);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        #lightbox.active {
            display: flex;
        }

        .lightbox-content {
            position: relative;
            max-width: 90%;
            max-height: 90%;
            background: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .lightbox-content img {
            max-width: 100%;
            max-height: 60vh;
            display: block;
            border-radius: 8px;
            margin: 0 auto;
        }

        .close {
            position: absolute;
            top: 10px;
            right: 15px;
            color: #0077b6;
            font-size: 35px;
            font-weight: bold;
            cursor: pointer;
        }

        .caption {
            color: #0077b6;
            font-weight: bold;
            margin: 10px 0;
        }
    `;

    addStyles(galleryStyles);
}

function createSimpleSearch() {
    
    const searchBox = document.createElement('div');
    searchBox.className = 'search-box';
    searchBox.innerHTML = `
        <h3>Search Our Services</h3>
        <input type="text" id="searchInput" placeholder="Search diabetes services...">
        <div id="searchResults" class="search-results"></div>
    `;
    const aboutSection = document.getElementById('about');
    if (aboutSection) {
        aboutSection.insertBefore(searchBox, aboutSection.firstChild);
    }
    
    // Simple search data
    const services = [
        'Diabetes Education Programs',
        'Blood Glucose Monitoring',
        'Medication Delivery Service', 
        'Prevention and Screening',
        'Nutrition Guidance',
        'Long-term Care Plans',
        'Insulin Management',
        'Healthy Lifestyle Support'
    ];
    
    const searchInput = document.getElementById('searchInput');
    const searchResults = document.getElementById('searchResults');
    
    searchInput.addEventListener('input', function() {
        const query = this.value.toLowerCase();
        
        if (query.length === 0) {
            searchResults.innerHTML = '';
            return;
        }
        const matches = services.filter(service => 
            service.toLowerCase().includes(query)
        );
        
        if (matches.length > 0) {
            searchResults.innerHTML = matches.map(service => 
                `<div class="search-result">${service}</div>`
            ).join('');
        } else {
            searchResults.innerHTML = '<div class="no-results">No services found. Try "education" or "medication"</div>';
        }
    });
    const searchStyles = `
        .search-box {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .search-box h3 {
            color: #0077b6;
            margin-bottom: 15px;
            text-align: center;
        }
        
        #searchInput {
            width: 100%;
            padding: 12px;
            border: 2px solid #0077b6;
            border-radius: 6px;
            font-size: 1rem;
            box-sizing: border-box;
        }
        
        #searchInput:focus {
            outline: none;
            border-color: #023e8a;
        }
        
        .search-results {
            margin-top: 15px;
        }
        
        .search-result {
            padding: 12px;
            margin-bottom: 8px;
            background: #e9f5ff;
            border-left: 4px solid #0077b6;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .search-result:hover {
            background: #d0ebff;
        }
        
        .no-results {
            padding: 15px;
            text-align: center;
            color: #666;
            background: #f8f9fa;
            border-radius: 4px;
        }
    `;
    
    addStyles(searchStyles);
}
function openLightbox(src, caption, description) {
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = lightbox.querySelector('img');
    const lightboxCaption = lightbox.querySelector('.caption');
    
    lightboxImg.src = src;
    lightboxCaption.textContent = caption;
    lightbox.classList.add('active');
    
    const closeBtn = lightbox.querySelector('.close');
    closeBtn.onclick = function() {
        lightbox.classList.remove('active');
    };
    lightbox.onclick = function(e) {
        if (e.target === lightbox) {
            lightbox.classList.remove('active');
        }
    };
}

function addSimpleAnimations() {
    
    const aboutSection = document.getElementById('about');
    if (aboutSection) {
        aboutSection.style.opacity = '0';
        aboutSection.style.transform = 'translateY(20px)';
        aboutSection.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        
        setTimeout(() => {
            aboutSection.style.opacity = '1';
            aboutSection.style.transform = 'translateY(0)';
        }, 300);
    }
    
    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(link => {
        link.style.transition = 'all 0.3s ease';
        
        link.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });
        
        link.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
}
function addStyles(css) {
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
}