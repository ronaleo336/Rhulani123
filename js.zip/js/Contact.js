document.addEventListener('DOMContentLoaded', function() {
    addContactForm();
    addLocationSection();
    addAnimations();
});

// Add contact form
function addContactForm() {
    const contactSection = document.getElementById('contact');
    
    const formHTML = `
        <div class="contact-form">
            <h3>Send us a Message</h3>
            <form id="messageForm">
                <input type="text" placeholder="Your Name" required>
                <input type="email" placeholder="Your Email" required>
                <textarea placeholder="Your Message" rows="4" required></textarea>
                <button type="submit">Send Message</button>
            </form>
        </div>
    `;
    
    contactSection.insertAdjacentHTML('beforeend', formHTML);
    
    
    const form = document.getElementById('messageForm');
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        
        const inputs = form.querySelectorAll('input, textarea');
        let isValid = true;
        
        inputs.forEach(input => {
            if (!input.value.trim()) {
                input.style.borderColor = '#dc3545';
                isValid = false;
            } else {
                input.style.borderColor = '';
            }
        });
        
        if (isValid) {
            alert('Thank you! Your message has been sent.');
            form.reset();
        }
    });
}


function addLocationSection() {
    const contactSection = document.getElementById('contact');
    
    const locationHTML = `
        <div class="location-info">
            <h3>Visit Our Location</h3>
            <div class="map-placeholder">
                <p><strong>Betes Headquarters</strong></p>
                <p>25 Shelley Road, Boksburg</p>
            </div>
        </div>
    `;
    
    contactSection.insertAdjacentHTML('beforeend', locationHTML);
}


function addAnimations() {
    const contactSection = document.getElementById('contact');
    contactSection.style.opacity = '0';
    contactSection.style.transition = 'opacity 0.8s ease';
    
    setTimeout(() => {
        contactSection.style.opacity = '1';
    }, 200);
    
   
    document.querySelectorAll('nav a').forEach(link => {
        link.style.transition = 'all 0.3s ease';
        link.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });
        link.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
}

const contactStyles = `
    .contact-form {
        margin: 25px 0;
        padding: 20px;
        background: white;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    
    .contact-form h3 {
        color: #0066cc;
        margin-bottom: 15px;
    }
    
    .contact-form input,
    .contact-form textarea {
        width: 100%;
        padding: 12px;
        margin: 8px 0;
        border: 2px solid #e0e0e0;
        border-radius: 6px;
        font-size: 1rem;
    }
    
    .contact-form input:focus,
    .contact-form textarea:focus {
        outline: none;
        border-color: #0066cc;
    }
    
    .contact-form button {
        width: 100%;
        padding: 12px;
        background: #0066cc;
        color: white;
        border: none;
        border-radius: 6px;
        font-size: 1rem;
        cursor: pointer;
        transition: background 0.3s;
    }
    
    .contact-form button:hover {
        background: #0099ff;
    }
    
    .location-info {
        margin: 25px 0;
        padding: 20px;
        background: white;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    
    .location-info h3 {
        color: #0066cc;
        margin-bottom: 15px;
    }
    
    .map-placeholder {
        text-align: center;
        padding: 20px;
        background: #e6f2ff;
        border-radius: 8px;
    }
    
    .map-placeholder p {
        margin: 8px 0;
    }
`;

const styleElement = document.createElement('style');
styleElement.textContent = contactStyles;
document.head.appendChild(styleElement);